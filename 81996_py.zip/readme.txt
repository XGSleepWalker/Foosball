﻿REGRAS DO JOGO:

O primeiro jogador a marcar 5 golos ganha o jogo.

MENU:

1 - Começar o jogo
2 - Fechar o jogo

Quando o jogo acaba, o vencedor tem de escrever o seu nome (max 4 chars).
A pontuação é o tempo da partida. Quanto menor o tempo da partida, melhor rank tem o jogador.
O jogo apenas mostra o 1º classificado.

Existe um bug quando o jogo acaba, o menu não faz reset completo e parte do campo aparecem no ecra.